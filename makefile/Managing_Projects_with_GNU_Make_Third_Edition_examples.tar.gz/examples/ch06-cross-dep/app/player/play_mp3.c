#include <player/play_mp3.h>

int
main( int argc, char ** argv )
{
  return 0;
}
